数独問題作成ツール アップデート

フォルダー構成

[lib_img]            : 取説用画像などを収めたフォルダー。
readme.txt           : このファイルです
suudoku_02_doc.html  : 前バージョンの取扱い説明書です
suudoku_03_doc.html  : 取扱い説明書です
z.suudoku_03.xlsm    : 数独作成ツール本体です


｢数独作成ツール アップデート｣を使用する前に、｢suudoku_03_doc.html｣をご一読下さい。
ツールの概要については｢suudoku_02_doc.html｣をご覧下さい。

｢数独作成ツール アップデート｣使用中に不具合、問題点などに気づかれた場合は、下記までお知らせ下さい。
また、転載を希望される場合もご連絡ください。

mail to : vff06643@nifty.ne.jp

Copyright Kazuo Kawamura. All rights reserved.

