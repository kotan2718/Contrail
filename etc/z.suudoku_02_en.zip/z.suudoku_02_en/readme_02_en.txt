Sudoku Puzzle Generator Tool

Folder Structure

[lib_img]               : sub folder containing images for the manual, etc.
readme_02_en.txt        : this file
suudoku_02_doc_en.html  : user's manual
z.suudoku_02_en.xlsm    : Sudoku Puzzle Generator Tool


Before using the "Sudoku Puzzle Generator Tool," please read "suudoku_02_doc_en.html".

If you encounter any bugs or issues while using the "Sudoku Puzzle Generator Tool," please report them to the address below.
Also, please contact us if you wish to reproduce this content.

mail to : vff06643@nifty.ne.jp

Copyright Kazuo Kawamura. All rights reserved.

