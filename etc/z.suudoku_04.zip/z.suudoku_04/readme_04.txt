数独問題作成ツール 別解法

フォルダー構成

[lib_img]            : 取説用画像などを収めたフォルダー
readme_04.txt        : このファイルです
suudoku_02_doc.html  : 前バージョンの取扱い説明書1です
suudoku_03_doc.html  : 前バージョンの取扱い説明書2です
suudoku_04_doc.html  : 取扱い説明書です
z.suudoku_04.xlsm    : ｢数独問題作成ツール 別解法｣の本体です
suudoku_dat.xlsm     : 作成されたデータの保存用サブツールです


｢数独問題作成ツール 別解法｣を使用する前に、｢suudoku_04_doc.html｣をご一読下さい。

ツールの概要については｢suudoku_02_doc.html｣をご覧下さい。
作成されたデータの保存方法の概要については｢suudoku_03_doc.html｣をご覧下さい。

｢数独問題作成ツール 別解法｣を使用中に不具合、問題点などに気づかれた場合は、下記までお知らせ下さい。
また、転載を希望される場合もご連絡ください。

mail to : vff06643@nifty.ne.jp

Copyright Kazuo Kawamura. All rights reserved.

