Sudoku Puzzle Generator Tool Another Method

Folder Structure

[lib_img]               : sub folder containing images for the manual, etc.
readme_en.txt           : this file
suudoku_02_doc_en.html  : Previous Version User's Manual 1
suudoku_03_doc_en.html  : Previous Version User's Manual 2
suudoku_04_doc_en.html  : user's manual
z.suudoku_04_en.xlsm    : Sudoku Puzzle Generator Tool Another Method


Before using the "Sudoku Puzzle Generator Tool Another Method," please read "suudoku_04_doc_en.html".

For an overview of the tool, please refer to “suudoku_02_doc.html”.
For an overview of how to save generated data, please refer to “suudoku_03_doc.html”.

If you encounter any bugs or issues while using the "Sudoku Puzzle Generator Tool Another Method,"
please report them to the address below.

Also, please contact us if you wish to reproduce this content.

mail to : vff06643@nifty.ne.jp

Copyright Kazuo Kawamura. All rights reserved.

